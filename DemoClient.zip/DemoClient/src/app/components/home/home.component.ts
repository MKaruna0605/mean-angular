import { Component, OnInit } from '@angular/core';
import {HomeapiService } from '../../services/homeapi.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  name:string;
  email:string;
  password:string;
  mobile:number;
  succMsg:any;
  errMsg:any;
  isEdited:boolean=false;
  profileData:any=[];
  id: any;
  constructor(private apiService:HomeapiService) { }

  ngOnInit() {
    this.getProfiles();
  }
  getProfiles(){
    this.apiService.getAllProfiles().subscribe((result:any)=>{
      if(result.success){
        console.log(result);
        this.profileData=result.data;
      }
    })
  }

  fomSubFun(){
    const obj={
      name:this.name,
      email:this.email,
      password:this.password,
      mobile:this.mobile
    }
    if(this.name!=undefined && this.email!=undefined && this.mobile!=undefined && this.password!=undefined){
      this.apiService.createUser(obj).subscribe((result:any)=>{
        if(result.success){
          this.succMsg=result.msg;
          this.profileData.push(obj)
          this.clearForm();
          setInterval(()=>{
            this.succMsg="";
          },5000);
        }else{
          this.errMsg=result.msg;
          setInterval(()=>{
            this.errMsg="";
          },5000);
        }
      })
    }else{
      this.errMsg="Provide requird fields";
          setInterval(()=>{
            this.errMsg="";
          },5000);
    }
   
  }
  editProfile(item){
    console.log(item);
    this.isEdited=true;
    this.id=item._id;
    this.name=item.name;
    this.mobile=item.mobile;
    this.email=item.email;
    this.password=item.password
  }
  updateProfileFun(){
    const obj={
      id:this.id,
      name:this.name,
      email:this.email,
      password:this.password,
      mobile:this.mobile
    }
    console.log(obj);
    if(this.name!=undefined && this.email!=undefined && this.mobile!=undefined && this.password!=undefined){
      this.apiService.updateProfile(obj).subscribe((result:any)=>{
        if(result.success){
          this.succMsg=result.msg;
          this.getProfiles();
          this.clearForm();
          setInterval(()=>{
            this.succMsg="";
          },5000);
        }else{
          this.errMsg=result.msg;
          setInterval(()=>{
            this.errMsg="";
          },5000);
        }
      })
    }else{
      this.errMsg="Provide requird fields";
          setInterval(()=>{
            this.errMsg="";
          },5000);
    }
  }
  deleteUser(id){
    console.log(id);
    this.apiService.deleteUserById(id).subscribe((result:any)=>{
      if(result.success){
        this.succMsg=result.msg;
        this.getProfiles();
        setInterval(()=>{
          this.succMsg="";
        },5000);
      }
    })
  }
  clearForm(){
    this.isEdited=false;
    this.name=null;
    this.mobile=null;
    this.email=null;
    this.password=null;
  }

}
