import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeapiService {
  apiurl:string="http://localhost:9001/apis";

  constructor( private http:HttpClient) { }


  createUser(obj){
    console.log(obj);
    return this.http.post(this.apiurl+'/createProfile',obj);
  }

  getAllProfiles(){
    return this.http.get(this.apiurl+'/getAllProfiles');
  }
  updateProfile(item){
    return this.http.put(this.apiurl+'/updateProfile',item);
  }
  deleteUserById(id){
    return this.http.delete(this.apiurl+'/deleteUser/'+id)
  }
}
