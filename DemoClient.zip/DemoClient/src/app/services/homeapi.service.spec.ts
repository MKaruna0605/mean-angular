import { TestBed } from '@angular/core/testing';

import { HomeapiService } from './homeapi.service';

describe('HomeapiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HomeapiService = TestBed.get(HomeapiService);
    expect(service).toBeTruthy();
  });
});
